Plugin.define do
    name "alcasar" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'valoriserDiv5'   }
]
end