Plugin.define do
    name "致远OA" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :md5 => '17ac348fcce0b320e7bfab3fe2858dfa'   },
    { :md5 => '2f761c27b6b7f9386bbd61403635dc42'   },
    { :md5 => '3c8df395ec2cbd72782286d18a286a9a'   },
    { :md5 => '57f307ad3764553df84e7b14b7a85432'   },
    { :md5 => 'cdc85452665e7708caed3009ecb7d4e2'   },
    { :text => '/seeyon/USER-DATA/IMAGES/LOGIN/login.gif'   },
    { :text => '/seeyon/common/'   }
]
end