Plugin.define do
    name "菲斯特诺期刊系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/images/i_arrow.gif', :md5 => '104867e9a97c512a74dd4724d6dcdffd'   },
    { :url => '/images/more27.gif', :md5 => 'dfd912127abc1e2b27505fc52cee6854'   },
    { :url => '/images/tt.gif', :md5 => '4c1a973b15d26bf1dac2d0c72a63ce90'   },
    { :url => '/images/tt.gif', :md5 => '4f08b4951aacfa3c8bcc74be8596f0ad'   }
]
end