Plugin.define do
    name "金笛邮件系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/jdwm/cgi/login.cgi?login'   }
]
end