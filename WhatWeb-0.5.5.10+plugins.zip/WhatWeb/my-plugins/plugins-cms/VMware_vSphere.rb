Plugin.define do
    name "VMware_vSphere" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'VMware vSphere'   }
]
end