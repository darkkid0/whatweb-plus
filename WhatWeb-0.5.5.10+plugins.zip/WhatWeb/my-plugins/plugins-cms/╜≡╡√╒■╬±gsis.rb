Plugin.define do
    name "金蝶政务gsis" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/kdgs/script/kdgs.js'     },
    { :text => '/kdgs/script/kdgs.js'    }
]
end