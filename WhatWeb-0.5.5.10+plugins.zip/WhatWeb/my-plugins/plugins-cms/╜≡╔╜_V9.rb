Plugin.define do
    name "金山_V9" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '金山终端安全系统V9.0Web控制台'   }
]
end