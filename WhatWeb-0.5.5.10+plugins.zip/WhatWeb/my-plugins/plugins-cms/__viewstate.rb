Plugin.define do
    name "__viewstate" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '__VIEWSTATE'   }
]
end