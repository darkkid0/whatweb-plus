Plugin.define do
    name "金山_V8" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :regexp => /北京金山安全管理系统技术有限公司|金山V8/  }
]
end