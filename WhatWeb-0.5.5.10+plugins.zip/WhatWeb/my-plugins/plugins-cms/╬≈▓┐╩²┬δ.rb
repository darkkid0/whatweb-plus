Plugin.define do
    name "西部数码" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'WT263CDN'   }
]
end