Plugin.define do
    name "露珠文章管理系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/adminimages/title.GIF', :md5 => '625f2078f5cc4bbffb4f1390f982b66b'   },
    { :url => '/images/luzhu.gif', :md5 => '9e6b211879d1b9c88f945b1a9afa38bf'   }
]
end