Plugin.define do
    name "迈捷邮件系统(magicmail)" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/aboutus/magicmail.gif'   }
]
end