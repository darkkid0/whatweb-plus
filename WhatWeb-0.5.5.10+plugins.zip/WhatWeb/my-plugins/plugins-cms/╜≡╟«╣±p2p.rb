Plugin.define do
    name "金钱柜p2p" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/plugins/timepicker/WdatePicker.js', :md5 => 'c9f6fa03efa814c0df575035774a0b6d'   }
]
end