Plugin.define do
    name "allnewsmanager_net" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'AllNewsManager'   },
]
end