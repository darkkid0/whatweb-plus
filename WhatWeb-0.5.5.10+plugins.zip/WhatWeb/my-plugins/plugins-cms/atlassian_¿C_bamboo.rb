Plugin.define do
    name "atlassian_–_bamboo" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1379982221'   }
]
end