Plugin.define do
    name "讯时网站管理系统cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/images/1012.gif', :md5 => '9fa0ca8c310b20af5671f0ce4d0a0567'   }
]
end