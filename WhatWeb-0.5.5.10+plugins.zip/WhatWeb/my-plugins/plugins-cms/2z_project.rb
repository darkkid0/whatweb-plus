Plugin.define do
    name "2z_project" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'Generator" content="2z project'   }
]
end