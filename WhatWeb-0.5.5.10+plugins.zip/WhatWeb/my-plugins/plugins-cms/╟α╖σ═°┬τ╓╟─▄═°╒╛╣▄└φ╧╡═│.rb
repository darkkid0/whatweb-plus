Plugin.define do
    name "青峰网络智能网站管理系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/admin/images/lg_fs.jpg', :md5 => '4b588db9466e935fcf6c9f0bfd0d67d6'   }
]
end