Plugin.define do
    name "良精南方" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/admin/Image/Login_tit.gif', :md5 => '352483c5ff2f284d92b38a9fab80cfcb'   },
    { :url => '/admin/image/title.gif', :md5 => '48015513094ff91334f8974f5dc123ad'   }
]
end