Plugin.define do
    name "android_webcam_server" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'Android Webcam Server'   }
]
end