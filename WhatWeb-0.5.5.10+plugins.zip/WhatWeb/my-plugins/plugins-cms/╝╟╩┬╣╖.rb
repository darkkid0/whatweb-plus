Plugin.define do
    name "记事狗" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/templates/default/admin/images/alert.png', :md5 => 'dd77ab35bfe56104e640a2a365d2110c'   },
    { :url => '/templates/default/qunstyles/t1.css', :md5 => '832e3939c83145e1b7b5ee9a155243bc'   }
]
end