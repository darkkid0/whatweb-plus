Plugin.define do
    name "青云客cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/images/ui/artlt_dot.png', :md5 => '632173e3898d4c601c82630a36043730'   },
    { :url => '/template/10001/cn/ui/logo.gif', :md5 => '405279583d52c4ae53a985ef7edb2334'   }
]
end