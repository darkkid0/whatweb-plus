Plugin.define do
    name "amiro.cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :regexp => /Amiro/, :search => 'body'  }
]
end