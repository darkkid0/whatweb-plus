Plugin.define do
    name "齐治堡垒机" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :md5 => '48ee373f098d8e96e53b7dd778f09ff4'   },
    { :regexp => /logo-icon-ico72.png|resources\/themes\/images\/logo-login.png/  }
]
end