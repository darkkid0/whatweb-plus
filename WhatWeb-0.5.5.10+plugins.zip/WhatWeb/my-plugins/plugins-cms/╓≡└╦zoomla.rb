Plugin.define do
    name "逐浪zoomla" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/style/images/win8_symbol_140x140.png'   },
    { :text => 'script src="http://code.zoomla.cn/'   }
]
end