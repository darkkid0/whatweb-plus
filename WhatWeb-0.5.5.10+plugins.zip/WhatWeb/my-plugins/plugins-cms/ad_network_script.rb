Plugin.define do
    name "ad_network_script" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'Web Administration Panel'   },
]
end