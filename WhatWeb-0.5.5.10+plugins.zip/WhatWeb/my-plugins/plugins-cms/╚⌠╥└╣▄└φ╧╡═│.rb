Plugin.define do
    name "若依管理系统" 
    authors [
        "winezero",
    ]
    version "0.1"
    matches [ 
    { :regexp => /ruoyi\/login.js|ruoyi\/js\/ry-ui.js/}, #成功
    #{ :url => "/favicon.ico", :md5 => 'e49fd30ea870c7a820464ca56a113e6e'   },  #失败
    #{ :url => "/favicon.ico", :mmh3 => '-1231872293'   },  #失败
    #{ :url => "/favicon.ico", :allhash => 'mmh3:-1231872293'   },  #成功
    #{:url => "/favicon.ico", :allhash => 'md5:e49fd30ea870c7a820464ca56a113e6e'   },  #失败,修复
    { :url => "/favicon.ico", :allhash => '-1231872293'   },  #成功
    #{ :url => "/favicon.ico", :allhash => 'e49fd30ea870c7a820464ca56a113e6e'   },  #失败,修复
    ]
end