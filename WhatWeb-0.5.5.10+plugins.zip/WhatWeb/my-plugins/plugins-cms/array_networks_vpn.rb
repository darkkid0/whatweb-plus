Plugin.define do
    name "array_networks_vpn" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'an_util.js'   }
]
end