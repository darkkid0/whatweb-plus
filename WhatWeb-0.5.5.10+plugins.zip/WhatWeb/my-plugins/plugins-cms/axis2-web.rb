Plugin.define do
    name "axis2-web" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'axis2-web/css/axis-style.css'   }
]
end