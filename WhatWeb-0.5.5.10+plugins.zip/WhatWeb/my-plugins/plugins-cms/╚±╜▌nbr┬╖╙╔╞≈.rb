Plugin.define do
    name "锐捷nbr路由器" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'free_nbr_login_form.png'   }
]
end