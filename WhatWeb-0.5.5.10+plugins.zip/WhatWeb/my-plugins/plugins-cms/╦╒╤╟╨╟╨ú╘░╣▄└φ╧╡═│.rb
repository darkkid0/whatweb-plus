Plugin.define do
    name "苏亚星校园管理系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/ws2004/Public/'   }
]
end