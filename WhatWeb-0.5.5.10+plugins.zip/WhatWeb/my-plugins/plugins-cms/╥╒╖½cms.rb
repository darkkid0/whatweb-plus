Plugin.define do
    name "艺帆cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/favicon.ico', :md5 => '6561b03b969300a5575592c78b6f4cc4'   }
]
end