Plugin.define do
    name "atshop" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => 'body', :regexp => /\.atshop\.io/  }
]
end