Plugin.define do
    name "binatone_wr3005n3" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'WR3005N3'   }
]
end