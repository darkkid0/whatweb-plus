Plugin.define do
    name "able_g2s" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/G2S/ShowSystem/css/cn.gif', :md5 => '30903faec6a3be5af62f7e8f5568a6ce'   },
    { :url => '/G2S/js/opendiv/login.js', :text => 'LoginForm.aspx?&KeepThis=true&TB_iframe=true&height=150&width=300\', false);'   }
]
end