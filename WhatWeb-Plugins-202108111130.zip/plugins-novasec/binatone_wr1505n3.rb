Plugin.define do
    name "binatone_wr1505n3" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'WR1505N3'   }
]
end