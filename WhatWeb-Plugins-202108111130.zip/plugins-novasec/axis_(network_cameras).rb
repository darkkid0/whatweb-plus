Plugin.define do
    name "axis_(network_cameras)" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1616143106'   }
]
end