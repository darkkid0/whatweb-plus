Plugin.define do
    name "3cx_phone_system" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '970132176'   }
]
end