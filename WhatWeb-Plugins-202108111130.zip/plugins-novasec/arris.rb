Plugin.define do
    name "arris" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1477563858'   }
]
end