Plugin.define do
    name "FIT2CLOUD-JumpServer-堡垒机" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '<title>JumpServer</title>'   }
]
end