Plugin.define do
    name "anleye(安居乐业cms)" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/themes/blue2012/css/adminlogin.css', :md5 => 'e5a550b632530b29c765ee0b21d317e5'   }
]
end