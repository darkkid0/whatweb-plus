Plugin.define do
    name "baidu统计" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'hm.baidu.com/h.js'   }
]
end