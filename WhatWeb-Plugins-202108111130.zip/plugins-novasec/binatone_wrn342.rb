Plugin.define do
    name "binatone_wrn342" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'WRN342'   }
]
end