Plugin.define do
    name "baidu_(ip_error_page)" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1507567067'   }
]
end