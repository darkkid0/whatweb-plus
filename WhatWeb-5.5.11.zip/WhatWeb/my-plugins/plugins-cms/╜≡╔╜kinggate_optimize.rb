Plugin.define do
    name "金山" 
    authors [
        "winezero",

    ]
    version "0.1"
matches [
    {:text=>'/src/system/login.php'},
    {:text=>'北京猎鹰安全科技有限公司'}
]
end