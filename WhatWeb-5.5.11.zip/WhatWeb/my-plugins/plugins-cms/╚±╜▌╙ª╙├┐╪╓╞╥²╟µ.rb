Plugin.define do
    name "锐捷应用控制引擎" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'window.open("/login.do","airWin'   },
    { :text => '锐捷应用控制引擎'   }
]
end