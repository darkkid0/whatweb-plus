Plugin.define do
    name "青果软件" 
    authors [
        "winezero",

    ]
    version "0.1"
matches [
    {:text=>'/jkingo.js'},
    {:text=>'KINGOSOFT'},
    {:text=>'SetKingoEncypt.jsp'},
    {:url=>'/images/_m10.GIF', :md5=>'5f18dc98d899dadec18bd506ff17f253'},
    {:url=>'/images/_m10.GIF', :md5=>'a8d1da39a1384e09297eeba522f5e375'},
    {:url=>'/images/button/bgbtn2_0.gif', :md5=>'061a9376bdb3bfaacfec43986456d455'},
    {:url=>'/images/index_border1.gif', :md5=>'6847aab9eafaa3b18c9779ddf34f92e2'},
    {:url=>'/images/index_border1.gif', :md5=>'8d0ced0a7a86c239f84d4e33cbf178b9'},
    {:url=>'/jwweb/images/button/bgbtn2_0.gif', :md5=>'061a9376bdb3bfaacfec43986456d455'},
    {:url=>'/jwweb/images/button/bgbtn2_0.gif', :md5=>'a42f7524df1ebb718ae0fb992602ea87'},
    {:url=>'/webs/sysdata.asmx', :md5=>'e259cdc8e7d3946d578ef8323476b245'},
    {:url=>'/xsweb/images/button/bgbtn2_0.gif', :md5=>'061a9376bdb3bfaacfec43986456d455'},
    {:url=>'/xsweb/images/button/bgbtn2_0.gif', :md5=>'a42f7524df1ebb718ae0fb992602ea87'}
]
end