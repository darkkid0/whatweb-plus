Plugin.define do
    name "aspthai_net-webboard" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'ASPThai.Net Webboard'   }
]
end