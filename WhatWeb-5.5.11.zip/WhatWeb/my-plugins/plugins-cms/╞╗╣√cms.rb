Plugin.define do
    name "苹果cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'maccms:voddaycount'   }
]
end