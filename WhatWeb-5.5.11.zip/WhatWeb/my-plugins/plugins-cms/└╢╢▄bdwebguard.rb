Plugin.define do
    name "蓝盾bdwebguard" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'BACKGROUND: url(images/loginbg.jpg) #e5f1fc'     },
    { :text => 'BACKGROUND: url(images/loginbg.jpg) #e5f1fc'    }
]
end