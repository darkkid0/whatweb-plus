Plugin.define do
    name "薄冰时期网站管理系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/admin/img/login1.gif', :md5 => '5d4557c6d09e6b156705d436990f3b7c'   }
]
end