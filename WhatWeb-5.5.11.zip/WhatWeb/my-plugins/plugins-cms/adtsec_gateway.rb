Plugin.define do
    name "adtsec_gateway" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '', :text => 'TPN-2G'   }
]
end