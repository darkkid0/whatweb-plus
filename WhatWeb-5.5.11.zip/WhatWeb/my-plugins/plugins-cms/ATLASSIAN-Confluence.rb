Plugin.define do
    name "ATLASSIAN-Confluence" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :md5 => 'b91d19259cf480661ef93b67beb45234'   },
    { :text => 'Atlassian Confluence'   }
]
end