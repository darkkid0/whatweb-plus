Plugin.define do
    name "Hadoop_Applications" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/cluster/app/application'   }
]
end