Plugin.define do
    name "蓝科cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/admin/images/left_title.gif', :md5 => '35613297cc0e20d5af99f7db02b877a2'   },
    { :url => '/admin/images/left_title2.gif', :md5 => 'f31bb2f1b0a0b21bca18a0ba4943609c'   }
]
end