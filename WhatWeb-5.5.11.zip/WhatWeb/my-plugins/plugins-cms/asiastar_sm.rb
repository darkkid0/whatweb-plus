Plugin.define do
    name "asiastar_sm" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/ws2004/Public/Images/bottom/add.gif', :md5 => 'fbb692b362177f35da508429a6d92d35'   }
]
end