Plugin.define do
    name "金蝶eas" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'easSessionId'     },
    { :text => 'easSessionId'    }
]
end