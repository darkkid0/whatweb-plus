Plugin.define do
    name "金色校园" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/admin/images/login/login_r3_c1.jpg', :md5 => '47183c1b2cc64e61e9d4b7b0038f57a7'   }
]
end