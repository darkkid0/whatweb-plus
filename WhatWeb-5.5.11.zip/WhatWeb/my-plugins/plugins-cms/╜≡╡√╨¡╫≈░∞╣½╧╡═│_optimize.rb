Plugin.define do
    name "金蝶协作办公系统" 
    authors [
        "winezero",

    ]
    version "0.1"
matches [
    {:url=>'/kingdee/images/login_bg.jpg', :md5=>'b0dafb425520fa98ed5342155f927a01'},
    {:url=>'/kingdee/login/images/formTable_left.gif', :md5=>'6608f7047b6738178c13ff4ddc5b51f3'},
    {:url=>'/kingdee/login/images/logo-kingdee.gif', :md5=>'f71f48eb366561b9a868baf89c95cd82'},
    {:url=>'/kingdee/weboa/images/formtable_bg.gif', :md5=>'ab560312b75bd5c9f048c5ba98c19dfd'},
    {:url=>'/oa/errors/images/ico_fhsy.gif', :md5=>'e4cd63dfacdfbd8ce5377a19b7325936'}
]
end