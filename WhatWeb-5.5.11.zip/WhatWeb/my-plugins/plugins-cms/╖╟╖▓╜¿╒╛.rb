Plugin.define do
    name "非凡建站" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/Admin/images/al_end_right.gif', :md5 => '27181f780a2c447a1d2a63ce70391b49'   },
    { :url => '/Admin/images/al_top.gif', :md5 => 'aa157057bb0cdab1cf90454ffc362a8e'   },
    { :url => '/images/Jobs_resume_up.gif', :md5 => '041718edc41fb801317c3a0b1f4b7ca9'   },
    { :url => '/qq/images/mid4.gif', :md5 => 'a2d236f6cf10df3342e017a8aea7de31'   }
]
end