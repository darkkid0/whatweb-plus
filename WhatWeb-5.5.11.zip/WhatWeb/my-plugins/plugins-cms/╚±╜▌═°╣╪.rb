Plugin.define do
    name "锐捷网关" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :md5 => 'd8d7c9138e93d43579ebf2e384745ba8'   }
]
end