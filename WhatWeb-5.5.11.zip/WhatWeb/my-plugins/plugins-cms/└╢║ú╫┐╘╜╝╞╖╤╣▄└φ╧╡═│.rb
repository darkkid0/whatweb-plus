Plugin.define do
    name "蓝海卓越计费管理系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :regexp => /蓝海卓越计费管理系统|星锐蓝海网络科技有限公司/  }
]
end