Plugin.define do
    name "锐捷_rg-dbs" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/css/impl-security.css'   },
    { :text => '/dbaudit/authenticate'   }
]
end