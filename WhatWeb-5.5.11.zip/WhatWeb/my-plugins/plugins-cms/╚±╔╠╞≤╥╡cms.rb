Plugin.define do
    name "锐商企业cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'href="/Writable/ClientImages/mycss.css'   }
]
end