Plugin.define do
    name "集时通讯程序" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/favicon.ico', :md5 => '8ba761dea4e805fc894763e895886656'   },
    { :url => '/userweb/images/system/outbound_cloud_nologo/login_logo.jpg', :md5 => 'ea0ce234a64fb31b82fb20047530cc29'   },
    { :url => '/userweb/images/tableft1.gif', :md5 => '8003e6104b2df85160c4ed1f75c76fed'   }
]
end