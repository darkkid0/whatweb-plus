Plugin.define do
    name "MetInfo-米拓建站" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ 
    { :md5 => '2a9541b5c2225ed2f28734c0d75e456f'   },
    { :text => 'MetInfo' },
    { :text => '/skin/style/metinfo.css' },
    { :text => '/skin/style/metinfo-v2.css' },
]
end