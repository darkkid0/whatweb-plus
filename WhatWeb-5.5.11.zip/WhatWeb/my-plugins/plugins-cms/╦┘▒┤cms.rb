Plugin.define do
    name "速贝cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/App_Themes/Admin/admin_images/btn_bg.png', :md5 => '39bb65a735ff068c3f83ae6b4430689d'   },
    { :url => '/App_Themes/Admin/admin_images/titlebg.jpg', :md5 => 'efebbac3e2941d4e916f40544458be79'   },
    { :url => '/App_Themes/admin/admin_images/login.jpg', :md5 => 'bb0a2e312b75d0413b97331291151da5'   },
    { :url => '/app_themes/admin/admin_images/login_tp.jpg', :md5 => 'a38f595f434ba70b962d7bd27dc6b729'   }
]
end