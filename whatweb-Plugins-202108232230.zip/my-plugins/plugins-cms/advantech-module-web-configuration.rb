Plugin.define do
name "advantech-module-web-configuration"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Advantech Module Web Configuration'},
]
end