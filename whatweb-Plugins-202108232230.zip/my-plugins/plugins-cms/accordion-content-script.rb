Plugin.define do
name "accordion-content-script"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'ddaccordion.js'},
]
end