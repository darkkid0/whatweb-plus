Plugin.define do
name "adyen" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Adyen'},
]
end