Plugin.define do
name "80cms-八零cms"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'80CMS'},
{:text=>'八零CMS'},
]
end