Plugin.define do
name "airlink-sierra-wireless-ace-manage"
authors [
"winezero",

]
version "0.1"
matches [
{:mmh3=>'-1571472432'},
]
end