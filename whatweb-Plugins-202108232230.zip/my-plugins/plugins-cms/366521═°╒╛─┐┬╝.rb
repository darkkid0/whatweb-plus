Plugin.define do
name "366521网站目录" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'366521网站目录'},
]
end