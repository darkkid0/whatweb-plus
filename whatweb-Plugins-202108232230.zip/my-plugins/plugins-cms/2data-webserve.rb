Plugin.define do
name "2data-webserve"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'B2Data WebServer'},
]
end