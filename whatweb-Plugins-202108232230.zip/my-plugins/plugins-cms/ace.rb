Plugin.define do
name "ace" 
authors [
"winezero",

]
version "0.1"
matches [
{:mmh3=>'-183163807'},
]
end