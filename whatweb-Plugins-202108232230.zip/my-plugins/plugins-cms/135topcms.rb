Plugin.define do
name "135topcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'135topCMS'},
]
end