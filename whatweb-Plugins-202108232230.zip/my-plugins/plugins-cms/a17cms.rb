Plugin.define do
name "a17cms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'A17CMS'},
]
end