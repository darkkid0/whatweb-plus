Plugin.define do
name "apache-pluto"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Pluto'},
]
end