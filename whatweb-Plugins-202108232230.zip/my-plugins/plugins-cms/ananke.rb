Plugin.define do
name "ananke" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Ananke'},
]
end