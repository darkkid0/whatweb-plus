Plugin.define do
name "arcadyan" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Arcadyan'},
]
end