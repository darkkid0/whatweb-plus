Plugin.define do
name "12样-12yang团购系统"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'12样_12yang团购系统'},
]
end