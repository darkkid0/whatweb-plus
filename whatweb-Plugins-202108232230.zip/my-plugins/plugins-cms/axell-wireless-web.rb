Plugin.define do
name "axell-wireless-web"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Axell Wireless Web'},
]
end