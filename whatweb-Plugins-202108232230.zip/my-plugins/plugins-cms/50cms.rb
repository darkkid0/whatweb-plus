Plugin.define do
name "50cms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'50CMS'},
]
end