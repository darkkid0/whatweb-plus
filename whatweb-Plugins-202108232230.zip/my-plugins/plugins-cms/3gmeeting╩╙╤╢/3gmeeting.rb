Plugin.define do
name "3gmeeting" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'3gmeeting'},
]
end