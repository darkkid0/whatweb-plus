Plugin.define do
name "alegrocart" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AlegroCart'},
]
end