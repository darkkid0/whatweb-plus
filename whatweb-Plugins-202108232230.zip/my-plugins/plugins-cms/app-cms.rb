Plugin.define do
name "app-cms"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'app cms'},
]
end