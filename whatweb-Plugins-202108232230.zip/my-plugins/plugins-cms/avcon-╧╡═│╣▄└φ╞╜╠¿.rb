Plugin.define do
name "avcon-系统管理平台" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AVCON-系统管理平台'},
]
end