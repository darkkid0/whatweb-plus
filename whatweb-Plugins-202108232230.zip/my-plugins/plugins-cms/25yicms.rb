Plugin.define do
name "25yicms" 
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'25yicms'},
{:text=>'Powered by 25yi'},
{:text=>'css/25yi.css'},
]
end