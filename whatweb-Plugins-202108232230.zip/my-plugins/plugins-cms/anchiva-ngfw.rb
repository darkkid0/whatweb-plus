Plugin.define do
name "anchiva-ngfw"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Anchiva NGFW'},
]
end