Plugin.define do
name "angulardart" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AngularDart'},
]
end