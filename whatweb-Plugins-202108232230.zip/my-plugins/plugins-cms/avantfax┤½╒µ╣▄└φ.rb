Plugin.define do
name "avantfax传真管理" 
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'content="Web 2.0 HylaFAX management'},
]
end