Plugin.define do
name "alerton-bcm-web"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alerton BCM-WEB'},
]
end