Plugin.define do
name "allegro-software-rompager"
authors [
"winezero",
]
version "0.1"
matches [
{:search=>"all", :text=>'Allegro-Software-RomPager'},
]
end