Plugin.define do
name "162100分类信息" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'162100分类信息'},
]
end