Plugin.define do
name "apereo-cas"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apereo CAS'},
]
end