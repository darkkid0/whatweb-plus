Plugin.define do
name "alpha-five-html-editor"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alpha Five HTML Editor'},
]
end