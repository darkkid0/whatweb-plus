Plugin.define do
name "alphapd" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'alphapd'},
]
end