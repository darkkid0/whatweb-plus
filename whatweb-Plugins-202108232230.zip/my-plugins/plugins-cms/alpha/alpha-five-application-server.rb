Plugin.define do
name "alpha-five-application-server"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alpha Five Application Server'},
]
end