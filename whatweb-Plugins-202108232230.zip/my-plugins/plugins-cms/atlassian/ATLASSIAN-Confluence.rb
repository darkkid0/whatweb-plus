Plugin.define do
name "ATLASSIAN-Confluence" 
authors [
"winezero",

]
version "0.1"
matches [
{:mmh3=>'-1642532491'},
{:mmh3=>'-305179312'},
{:md5=>'b91d19259cf480661ef93b67beb45234'},
{:search=>"headers", :text=>'x-confluence'},
{:text=>'Atlassian Confluence'},
]
end