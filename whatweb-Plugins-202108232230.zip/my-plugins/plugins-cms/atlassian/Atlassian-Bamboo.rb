Plugin.define do
name "Atlassian-Bamboo" 
authors [
    "winezero",
]
version "0.1"
matches [
{:mmh3=>'-1379982221'},
{:url=>"/favicon.ico",:allhash=>"43ba066789e749f9ef591dc086f3cd14"},
{:url=>"/favicon.ico",:allhash=>"a83dfece1c0e9e3469588f418e1e4942"},
]
end