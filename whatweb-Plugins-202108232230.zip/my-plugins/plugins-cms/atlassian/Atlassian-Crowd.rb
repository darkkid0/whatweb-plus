Plugin.define do
name "Atlassian-Crowd" 
authors [
    "winezero",
]
version "0.1"
matches [
{:url=>"/favicon.ico",:allhash=>"1275afc920a53a9679d2d0e8a5c74054"},
]
end