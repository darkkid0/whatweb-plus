Plugin.define do
name "Atlassian-Jira-Bug-Tracker" 
authors [
    "winezero",
]
version "0.1"
matches [
{:url=>"/favicon.ico",:allhash=>"04d89d5b7a290334f5ce37c7e8b6a349"},
]
end