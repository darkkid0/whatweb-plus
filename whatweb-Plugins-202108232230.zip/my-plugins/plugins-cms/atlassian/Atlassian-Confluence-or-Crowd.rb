Plugin.define do
name "Atlassian-Confluence-or-Crowd" 
authors [
    "winezero",
]
version "0.1"
matches [
{:url=>"/favicon.ico",:allhash=>"12888a39a499eb041ca42bf456aca285"},
{:url=>"/favicon.ico",:allhash=>"3341c6d3c67ccdaeb7289180c741a965"},
]
end