Plugin.define do
name "adsubtract-proxy"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"headers", :text=>'AdSubtract'},
]
end