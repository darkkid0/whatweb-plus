Plugin.define do
name "afterlogic-webmail-lite"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AfterLogic WebMail Lite'},
]
end