Plugin.define do
name "asymptix-php-framework"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Asymptix PHP Framework'},
]
end