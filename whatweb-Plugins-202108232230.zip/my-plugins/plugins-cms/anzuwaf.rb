Plugin.define do
name "anzuwaf" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"headers", :text=>'AnZuWAF'},
]
end