Plugin.define do
name "173cms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'173CMS'},
]
end