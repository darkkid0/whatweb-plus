Plugin.define do
name "av-tech-video-web"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AV-TECH Video Web'},
]
end