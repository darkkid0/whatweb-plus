Plugin.define do
name "avtech-tempager"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AVTECH TemPageR'},
]
end