Plugin.define do
name "av-tech-av787-video-web-server"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AV-TECH AV787 Video Web Server'},
]
end