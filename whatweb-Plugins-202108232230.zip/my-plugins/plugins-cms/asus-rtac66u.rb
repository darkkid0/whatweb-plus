Plugin.define do
name "asus-rtac66u"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'RT-AC66U'},
]
end