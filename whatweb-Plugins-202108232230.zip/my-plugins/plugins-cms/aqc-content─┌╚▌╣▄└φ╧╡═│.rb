Plugin.define do
name "aqc-content内容管理系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AQC-Content内容管理系统'},
]
end