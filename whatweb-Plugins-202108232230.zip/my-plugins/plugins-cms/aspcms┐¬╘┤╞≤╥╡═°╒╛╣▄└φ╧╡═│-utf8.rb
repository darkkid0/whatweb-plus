Plugin.define do
name "aspcms开源企业网站管理系统-utf8"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'/inc/AspCms_AdvJs.asp'},
{:text=>'Powered by ASPCMS'},
{:text=>'content="ASPCMS'},
]
end