Plugin.define do
name "171cms-711cms"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'171CMS'},
]
end