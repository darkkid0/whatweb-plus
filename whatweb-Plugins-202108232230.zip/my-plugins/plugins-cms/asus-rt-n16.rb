Plugin.define do
name "asus-rt-n16" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ASUS-RT-N16'},
]
end