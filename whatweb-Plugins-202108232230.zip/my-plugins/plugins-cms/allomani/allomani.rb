Plugin.define do
name "allomani" 
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'Programmed By Allomani'},
]
end