Plugin.define do
name "aten-kvm"
authors [
"winezero",

]
version "0.1"
matches [
{:url=>'/img/top_logo.gif', :md5=>'6b327a45dfcd635a00b8712bdf6c11d9'},
]
end