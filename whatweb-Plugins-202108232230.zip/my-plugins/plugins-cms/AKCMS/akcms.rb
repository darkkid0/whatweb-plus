Plugin.define do
name "akcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:url=>'/images/admin/logo.gif', :md5=>'b2d6d8861f20a1791611d1f21d2ba4bf'},
{:url=>'/images/admin/sprites.png', :md5=>'80d5e4b529aeb4d4516045918e3f7e47'},
{:url=>'/static/images/ak3.jpg', :md5=>'b0f53ec1eba8fcbea5e2a831325bbeab'},
]
end