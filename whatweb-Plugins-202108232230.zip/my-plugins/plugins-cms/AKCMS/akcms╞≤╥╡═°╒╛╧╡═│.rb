Plugin.define do
name "akcms企业网站系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AKCMS企业网站系统'},
]
end