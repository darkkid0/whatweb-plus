Plugin.define do
name "ale.js" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Ale.js'},
]
end