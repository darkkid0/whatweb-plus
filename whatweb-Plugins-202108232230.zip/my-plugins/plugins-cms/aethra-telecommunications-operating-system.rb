Plugin.define do
name "aethra-telecommunications-operating-system"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Aethra Telecommunications OS'},
{:search=>"headers", :text=>'atos'},
]
end