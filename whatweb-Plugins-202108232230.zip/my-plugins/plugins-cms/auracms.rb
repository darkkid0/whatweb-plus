Plugin.define do
name "auracms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AuraCMS'},
]
end