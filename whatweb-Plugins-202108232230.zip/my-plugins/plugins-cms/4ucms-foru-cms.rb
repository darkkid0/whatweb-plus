Plugin.define do
name "4ucms-foru-cms"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'4UCMS'},
{:search=>"all", :text=>'ForU CMS'},
]
end