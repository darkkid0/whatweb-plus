Plugin.define do
name "artcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ArtCMS'},
]
end