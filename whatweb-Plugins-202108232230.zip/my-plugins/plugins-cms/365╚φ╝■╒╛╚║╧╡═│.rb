Plugin.define do
name "365软件站群系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'365软件站群系统'},
]
end