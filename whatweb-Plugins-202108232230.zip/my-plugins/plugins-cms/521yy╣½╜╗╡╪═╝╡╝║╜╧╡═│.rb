Plugin.define do
name "521yy公交地图导航系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'521YY公交地图导航系统'},
]
end