Plugin.define do
name "aimeewmt-内容管理系统"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AimeeWMT_内容管理系统'},
]
end