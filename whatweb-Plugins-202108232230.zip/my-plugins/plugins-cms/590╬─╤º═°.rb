Plugin.define do
name "590文学网" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'590文学网'},
]
end