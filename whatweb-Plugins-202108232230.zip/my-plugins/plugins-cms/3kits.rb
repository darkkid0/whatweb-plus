Plugin.define do
name "3kits" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'3KITS'},
]
end