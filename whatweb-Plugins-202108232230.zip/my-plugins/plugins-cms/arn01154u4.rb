Plugin.define do
name "arn01154u4" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"headers", :text=>'ARN01154U4'},
]
end