Plugin.define do
name "asp开源商城系统yothshop" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Asp开源商城系统YothSHOP'},
]
end