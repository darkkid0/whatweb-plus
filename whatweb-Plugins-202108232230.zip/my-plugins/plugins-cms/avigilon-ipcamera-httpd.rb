Plugin.define do
name "avigilon-ipcamera-httpd"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Avigilon ipcamera httpd'},
]
end