Plugin.define do
name "alsovalue" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alsovalue'},
]
end