Plugin.define do
name "188旅游网站管理系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'188旅游网站管理系统'},
]
end