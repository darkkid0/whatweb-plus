Plugin.define do
name "apache-syncope"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Syncope'},
]
end