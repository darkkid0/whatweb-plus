Plugin.define do
name "adikiss-asik"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'adikiss ASIK'},
]
end