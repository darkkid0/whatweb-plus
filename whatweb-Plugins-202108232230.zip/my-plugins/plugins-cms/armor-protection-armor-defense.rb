Plugin.define do
name "armor-protection-armor-defense"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Armor Defense'},
{:search=>"all", :text=>'Armor Protection'},
]
end