Plugin.define do
name "acsoft" 
authors [
"winezero",

]
version "0.1"
matches [
{:url=>'/images/tagright.gif', :md5=>'2af1905871bb3464a712d73aa6460bb0'},
]
end