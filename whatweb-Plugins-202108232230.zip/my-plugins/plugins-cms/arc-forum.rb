Plugin.define do
name "arc-forum"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Arc Forum'},
]
end