Plugin.define do
name "aiot结构健康监测系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AIOT结构健康监测系统'},
]
end