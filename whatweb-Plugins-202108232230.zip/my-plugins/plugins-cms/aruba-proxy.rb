Plugin.define do
name "aruba-proxy" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'aruba-proxy'},
]
end