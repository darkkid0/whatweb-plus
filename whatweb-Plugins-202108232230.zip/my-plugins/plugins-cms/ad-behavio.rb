Plugin.define do
name "ad-behavio"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"headers", :text=>'bb2_screener_'},
]
end