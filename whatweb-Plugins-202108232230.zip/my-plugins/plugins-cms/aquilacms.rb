Plugin.define do
name "aquilacms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>'body', :regexp=>/AquilaCMS/},
]
end