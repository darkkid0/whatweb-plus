Plugin.define do
name "21百合婚恋网系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'21百合婚恋网系统'},
]
end