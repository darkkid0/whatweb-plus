Plugin.define do
name "aiohttp" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'aiohttp'},
]
end