Plugin.define do
name "ajenti" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ajenti'},
]
end