Plugin.define do
name "_viewstate"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'__VIEWSTATE'},
]
end