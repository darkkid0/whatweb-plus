Plugin.define do
name "7384微招聘系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'7384微招聘系统'},
]
end