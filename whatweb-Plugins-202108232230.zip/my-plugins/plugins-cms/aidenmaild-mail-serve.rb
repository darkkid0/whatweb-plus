Plugin.define do
name "aidenmaild-mail-serve"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'RaidenMAILD Mail Server'},
]
end