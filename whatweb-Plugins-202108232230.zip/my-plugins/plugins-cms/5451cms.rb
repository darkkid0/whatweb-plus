Plugin.define do
name "5451cms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'5451CMS'},
]
end