Plugin.define do
name "atmail" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"headers", :text=>'atmail6'},
{:text=>'FixShowMail'},
{:text=>'Powered by Atmail'},
{:url=>"/favicon.ico",:allhash=>"705d63d8f6f485bd40528394722b5c22"},
]
end