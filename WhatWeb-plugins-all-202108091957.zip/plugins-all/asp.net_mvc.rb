Plugin.define do
    name "asp.net_mvc" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'Aspnetmvc'   }
]
end