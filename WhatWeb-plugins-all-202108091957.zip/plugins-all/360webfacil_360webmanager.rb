Plugin.define do
    name "360webfacil_360webmanager" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '360WebManager Software'     },
    { :text => 'publico/template/'     },
    { :text => 'publico/template/'    }
]
end