Plugin.define do
    name "archivematica" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1378182799'   }
]
end