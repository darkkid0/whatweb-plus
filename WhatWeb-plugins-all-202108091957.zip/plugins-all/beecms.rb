Plugin.define do
    name "beecms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'template/default/images/slides.min.jquery.js'   }
]
end