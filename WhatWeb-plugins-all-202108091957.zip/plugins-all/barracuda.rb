Plugin.define do
    name "barracuda" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '1436966696'   }
]
end