Plugin.define do
    name "bitnami" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1607644090'   }
]
end