Plugin.define do
    name "360企业版" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '360EntInst'     },
    { :text => '360EntWebAdminMD5Secret'     },
    { :text => '360EntWebAdminMD5Secret'    }
]
end