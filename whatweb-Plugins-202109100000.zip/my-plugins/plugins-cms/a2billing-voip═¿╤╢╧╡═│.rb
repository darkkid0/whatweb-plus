Plugin.define do
name "a2billing-voip通讯系统"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'a2billing VOIP通讯系统'},
]
end