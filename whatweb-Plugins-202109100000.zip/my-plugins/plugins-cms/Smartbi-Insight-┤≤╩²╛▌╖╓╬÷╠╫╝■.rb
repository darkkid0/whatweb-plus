Plugin.define do
name "Smartbi-Insight-大数据分析套件"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Smartbi 大数据分析套件'},
{:text=>'smartbi.gcf.gcfutil'},
]
end