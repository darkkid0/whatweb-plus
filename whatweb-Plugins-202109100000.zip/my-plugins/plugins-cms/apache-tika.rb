Plugin.define do
name "apache-tika"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Tika'},
]
end