Plugin.define do
name "51yes" 
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'51yes.com/click.aspx'},
]
end