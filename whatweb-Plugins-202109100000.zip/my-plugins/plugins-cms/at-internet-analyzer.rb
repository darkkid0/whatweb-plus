Plugin.define do
name "at-internet-analyzer"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AT Internet Analyzer'},
]
end