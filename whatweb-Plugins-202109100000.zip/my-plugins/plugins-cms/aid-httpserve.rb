Plugin.define do
name "aid-httpserve"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'RAID HTTPServer'},
]
end