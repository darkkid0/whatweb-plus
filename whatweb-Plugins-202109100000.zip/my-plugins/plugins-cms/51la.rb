Plugin.define do
name "51la" 
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'js.users.51.la'},
]
end