Plugin.define do
name "apple-airport"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apple AirPort'},
]
end