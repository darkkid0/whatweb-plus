Plugin.define do
name "anymacromail" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'anymacromail'},
{:url=>'/help/css.css', :text=>'.any_table {width:90%;border-collapse:collapse}'},
{:url=>'/image/reuser.gif', :md5=>'701829e57bb05f05a404e4dc75eafbdb'},
]
end