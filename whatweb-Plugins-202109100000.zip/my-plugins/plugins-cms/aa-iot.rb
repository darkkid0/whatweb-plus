Plugin.define do
name "aa-iot" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AA-IOT'},
]
end