Plugin.define do
name "accessibe" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>'body', :regexp=>/acsbapp?\.com..*.acsb\.js/},
]
end