Plugin.define do
name "array-networks-vpn"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Array Networks VPN'},
{:text=>'an_util.js'},
]
end