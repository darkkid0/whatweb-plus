Plugin.define do
name "asroute"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'BASrouter'},
]
end