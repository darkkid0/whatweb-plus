Plugin.define do
name "awmall多用户微信商城系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AwMall多用户微信商城系统'},
]
end