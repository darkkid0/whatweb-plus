Plugin.define do
name "apache-storm"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Storm'},
]
end