Plugin.define do
name "asp168欧虎" 
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'default.php?mod=article&do=detail&tid'},
{:text=>'upload/moban/images/style.css'},
]
end