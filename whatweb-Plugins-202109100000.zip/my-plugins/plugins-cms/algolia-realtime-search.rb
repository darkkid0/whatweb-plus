Plugin.define do
name "algolia-realtime-search"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Algolia Realtime Search'},
]
end