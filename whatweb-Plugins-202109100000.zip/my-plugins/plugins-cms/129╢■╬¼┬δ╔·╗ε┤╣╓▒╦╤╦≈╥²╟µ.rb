Plugin.define do
name "129二维码生活垂直搜索引擎" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'129二维码生活垂直搜索引擎'},
]
end