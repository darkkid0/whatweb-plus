Plugin.define do
name "arevb!微博客系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Arevb!微博客系统'},
]
end