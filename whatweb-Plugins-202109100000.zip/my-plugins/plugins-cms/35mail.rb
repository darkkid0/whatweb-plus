Plugin.define do
name "35mail" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'35Mail'},
]
end