Plugin.define do
name "apache-geronimo"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Geronimo'},
]
end