Plugin.define do
name "adultvideoscript" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AdultVideoScript'},
]
end