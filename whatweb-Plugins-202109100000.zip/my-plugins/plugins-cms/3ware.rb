Plugin.define do
name "3ware" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'3ware'},
]
end