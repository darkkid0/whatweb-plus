Plugin.define do
name "angular-io-angularjs"
authors [
"winezero",

]
version "0.1"
matches [
{:mmh3=>'-1255347784'},
]
end