Plugin.define do
name "ampcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AmpCMS'},
]
end