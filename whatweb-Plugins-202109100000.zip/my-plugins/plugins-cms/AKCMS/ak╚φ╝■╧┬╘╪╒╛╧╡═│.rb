Plugin.define do
name "ak软件下载站系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AK软件下载站系统'},
]
end