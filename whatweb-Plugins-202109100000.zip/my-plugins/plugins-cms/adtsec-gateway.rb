Plugin.define do
name "adtsec-gateway"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'adtsec_gateway'},
{:url=>'', :text=>'TPN-2G'},
]
end