Plugin.define do
name "anchor-cms"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Anchor CMS'},
]
end