Plugin.define do
name "accessible-portal"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Accessible Portal'},
]
end