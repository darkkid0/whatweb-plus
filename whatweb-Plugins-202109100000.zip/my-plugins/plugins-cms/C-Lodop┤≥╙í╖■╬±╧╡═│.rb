Plugin.define do
name "C-Lodop打印服务系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:regexp=>/\/CLodopfuncs.js|www.c-lodop.com/},
]
end