Plugin.define do
name "6117支付平台程序" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'6117支付平台程序'},
]
end