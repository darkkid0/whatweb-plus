Plugin.define do
name "amh主机面板" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AMH主机面板'},
]
end