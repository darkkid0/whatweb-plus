Plugin.define do
name "apphp-商业网站目录"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ApPHP_商业网站目录'},
]
end