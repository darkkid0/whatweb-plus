Plugin.define do
name "86cms企业网站管理系统" 
authors [
"winezero",
]
version "0.2"
matches [
{:text=>'86CMS企业网站管理系统'},
{:url=>'/adfile/ad9.js', :md5=>'996507b745203776e2915e8878344146'},
{:url=>'/admin/images/login_06.jpg', :md5=>'d7e74c7a56081ebe8415c6ffc1d7a11a'},
]
end