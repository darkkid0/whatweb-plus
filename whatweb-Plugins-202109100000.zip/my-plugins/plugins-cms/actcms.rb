Plugin.define do
name "actcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:url=>'/ACT_inc/ItemBg.gif', :md5=>'9cfc31ea9b376230b76bfbbf70b814bf'},
{:url=>'/ACT_inc/ItemBg.gif', :md5=>'f2da68ac4c619e437e635b04fe655974'},
{:url=>'/ACT_inc/share/minusbottom.gif', :md5=>'934a2b40df618be35f7488ac3245aca6'},
{:url=>'/ACT_inc/share/minusbottom.gif', :md5=>'b09d684cca7135ef728141aaf2464baa'},
{:url=>'/Admin/Images/bg_admin.jpg', :md5=>'6b1185f2df41f38247d20f1f5b53c0cc'},
{:url=>'/Admin/Images/bg_admin.jpg', :md5=>'ffa3e0ce2e3024aea0a60dc49dfd871c'},
{:url=>'/Admin/Images/logo.jpg', :md5=>'16088c9aeb5b77ef3a07db4e08834880'},
{:url=>'/Admin/Images/logo.jpg', :md5=>'df86ce8c3068dafd2d5d2b0e40cde667'},
{:url=>'/images/act_1.gif', :md5=>'b99464b11b2cc0a0403f308a775d9b7b'},
{:url=>'/images/logo.gif', :md5=>'02d47a2780fdadd0086215693f3a6b5f'},
{:url=>'/images/reg.gif', :md5=>'c81932053e6ac8df6077e5c7ad241ae8'},
]
end