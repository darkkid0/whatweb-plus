Plugin.define do
name "adobe-flash-media"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Adobe Flash Media'},
]
end