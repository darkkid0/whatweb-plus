Plugin.define do
name "adobe-dtm"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Adobe DTM'},
]
end