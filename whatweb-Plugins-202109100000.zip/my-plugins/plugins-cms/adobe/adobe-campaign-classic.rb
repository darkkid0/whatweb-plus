Plugin.define do
name "adobe-campaign-classic"
authors [
"winezero",

]
version "0.1"
matches [
{:mmh3=>'-333791179'},
]
end