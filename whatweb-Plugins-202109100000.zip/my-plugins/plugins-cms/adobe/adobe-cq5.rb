Plugin.define do
name "adobe-cq5"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'_jcr_content'},
]
end