Plugin.define do
name "anchorcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AnchorCMS'},
]
end