Plugin.define do
name "asle"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'Basler AG'},
]
end