Plugin.define do
name "25175企业客户管理系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'25175企业客户管理系统'},
]
end