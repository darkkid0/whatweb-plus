Plugin.define do
name "521yy歪歪网络备忘录" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'521YY歪歪网络备忘录'},
]
end