Plugin.define do
name "alpha-anywhere-application-server"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alpha Anywhere Application Server'},
]
end