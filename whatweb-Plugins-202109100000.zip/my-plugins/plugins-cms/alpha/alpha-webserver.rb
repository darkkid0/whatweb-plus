Plugin.define do
name "alpha-webserver"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ALPHA-WebServer'},
]
end