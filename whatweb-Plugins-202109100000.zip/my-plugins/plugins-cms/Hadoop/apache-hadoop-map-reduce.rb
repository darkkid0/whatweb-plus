Plugin.define do
name "apache-hadoop-map-reduce"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Hadoop Map_Reduce'},
]
end