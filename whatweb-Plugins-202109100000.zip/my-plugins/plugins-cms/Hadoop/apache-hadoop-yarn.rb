Plugin.define do
name "apache-hadoop-yarn"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Hadoop YARN'},
]
end