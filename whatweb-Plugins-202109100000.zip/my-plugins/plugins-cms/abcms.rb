Plugin.define do
name "abcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:url=>'/images-global/zoom/zoom-caption-fill.png', :md5=>'30622d7dfb42b9e1d0e78b1fdd9340ce'},
{:url=>'/images-global/zoom/zoom-caption-fill.png', :md5=>'4b6f9654b24b1ef9670b361642f444b2'},
{:url=>'/install/images/00.png', :md5=>'1513efc63c01b27ec75402e4b0d3b95f'},
{:url=>'/install/images/00.png', :md5=>'c5ee1709a853229d2c91d736eda10051'},
]
end