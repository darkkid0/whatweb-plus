Plugin.define do
name "appex-lotwan"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'APPEX LotWAN'},
]
end