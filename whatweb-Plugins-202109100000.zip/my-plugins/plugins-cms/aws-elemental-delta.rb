Plugin.define do
name "aws-elemental-delta"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AWS Elemental Delta'},
]
end