Plugin.define do
name "are-infotech"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ARE InfoTech'},
]
end