Plugin.define do
name "activage-project"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ACTIVAGE Project'},
]
end