Plugin.define do
name "99cms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'99CMS'},
]
end