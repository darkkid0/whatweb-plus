Plugin.define do
name "apollo" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apollo'},
]
end