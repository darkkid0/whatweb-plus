Plugin.define do
name "asp.net-mvc"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"headers", :text=>'Aspnetmvc'},
]
end