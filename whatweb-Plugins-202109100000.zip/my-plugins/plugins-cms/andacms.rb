Plugin.define do
name "andacms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AndaCMS'},
]
end