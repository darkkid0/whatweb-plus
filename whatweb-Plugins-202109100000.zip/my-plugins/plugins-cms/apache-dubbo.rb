Plugin.define do
name "apache-dubbo"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Dubbo'},
]
end