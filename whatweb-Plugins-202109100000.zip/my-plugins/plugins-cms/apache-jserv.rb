Plugin.define do
name "apache-jserv"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Apache Jserv'},
]
end