Plugin.define do
name "alcad-iptv-web"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alcad IPTV Web'},
]
end