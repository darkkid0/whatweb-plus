Plugin.define do
name "128uu酒店预订系统php版" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'128UU酒店预订系统PHP版'},
]
end