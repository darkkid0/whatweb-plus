Plugin.define do
name "atripower"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'atripower'},
{:url=>'/Scripts/Common.js', :text=>'GenerateCalendar'},
]
end