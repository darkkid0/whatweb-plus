Plugin.define do
name "3gcms" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'3GCMS'},
]
end