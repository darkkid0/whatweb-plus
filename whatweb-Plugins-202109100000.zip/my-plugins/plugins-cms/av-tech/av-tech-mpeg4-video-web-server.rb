Plugin.define do
name "av-tech-mpeg4-video-web-server"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AV-TECH Mpeg4 Video Web Server'},
]
end