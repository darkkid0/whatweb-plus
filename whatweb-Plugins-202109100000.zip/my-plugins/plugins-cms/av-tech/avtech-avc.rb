Plugin.define do
name "avtech-avc"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AVTECH avc'},
]
end