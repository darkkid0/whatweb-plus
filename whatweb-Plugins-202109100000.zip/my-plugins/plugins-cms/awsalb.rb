Plugin.define do
name "awsalb"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AWSALB'},
]
end