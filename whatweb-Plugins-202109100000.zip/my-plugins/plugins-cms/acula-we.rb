Plugin.define do
name "acula-we"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'Bacula Web'},
{:text=>'Bacula-Web'},
{:text=>'Webacula'},
{:text=>'bacula-web'},
]
end