Plugin.define do
name "auction-network-webs"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Auction Network Webs'},
]
end