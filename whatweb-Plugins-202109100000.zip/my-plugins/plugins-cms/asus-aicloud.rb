Plugin.define do
name "asus-aicloud"
authors [
"winezero",

]
version "0.1"
matches [
{:mmh3=>'552592949'},
]
end