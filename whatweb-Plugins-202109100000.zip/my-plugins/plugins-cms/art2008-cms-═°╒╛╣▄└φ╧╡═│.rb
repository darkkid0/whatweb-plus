Plugin.define do
name "art2008-cms-网站管理系统"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Art2008_CMS_网站管理系统'},
]
end