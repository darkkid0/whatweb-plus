Plugin.define do
name "acsno网络探针" 
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'探针管理与测试系统-登录界面'},
{:url=>'/images_2_2/favicon.png', :md5=>'53e754664fd16dde231fd2c1a4063997'},
]
end