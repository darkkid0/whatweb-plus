Plugin.define do
name "airlink101" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'airlink101'},
]
end