Plugin.define do
name "abiao-cms文章管理系统"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ABIAO_CMS文章管理系统'},
]
end