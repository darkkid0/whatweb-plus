Plugin.define do
name "aptcacherng" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'AptCacherNg'},
]
end