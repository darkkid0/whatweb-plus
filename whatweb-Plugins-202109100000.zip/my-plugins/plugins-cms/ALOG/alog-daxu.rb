Plugin.define do
name "alog-daxu"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alog_DaXu'},
]
end