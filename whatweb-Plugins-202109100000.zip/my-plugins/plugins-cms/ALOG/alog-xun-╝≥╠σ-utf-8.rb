Plugin.define do
name "alog-xun-简体-utf-8"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alog_Xun_简体_utf-8'},
]
end