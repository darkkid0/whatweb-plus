Plugin.define do
name "alog-ben"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Alog_Ben'},
]
end