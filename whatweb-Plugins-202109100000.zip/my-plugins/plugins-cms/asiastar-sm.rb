Plugin.define do
name "asiastar-sm"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'asiastar_sm'},
{:url=>'/ws2004/Public/Images/bottom/add.gif', :md5=>'fbb692b362177f35da508429a6d92d35'},
]
end