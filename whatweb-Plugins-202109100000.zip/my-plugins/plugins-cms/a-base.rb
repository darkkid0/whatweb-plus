Plugin.define do
name "a-base" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'A-Base'},
]
end