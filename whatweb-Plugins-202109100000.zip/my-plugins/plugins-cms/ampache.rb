Plugin.define do
name "ampache" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'ampache'},
{:url=>"/favicon.ico",:allhash=>"2e9545474ee33884b5fb8a9a0b8806dd"},
]
end