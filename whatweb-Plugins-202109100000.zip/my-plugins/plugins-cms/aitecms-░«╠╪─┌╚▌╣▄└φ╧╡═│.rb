Plugin.define do
name "aitecms-爱特内容管理系统"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'aitecms'},
{:search=>"all", :text=>'爱特cms'},
{:text=>'爱特内容管理系统_aitecms'},
]
end