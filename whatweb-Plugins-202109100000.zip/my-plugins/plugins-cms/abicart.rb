Plugin.define do
name "abicart" 
authors [
"winezero",

]
version "0.1"
matches [
{:regexp=>/Abicart/, :search=>'body'},
]
end