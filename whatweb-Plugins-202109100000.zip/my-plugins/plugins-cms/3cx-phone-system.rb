Plugin.define do
name "3cx-phone-system"
authors [
"winezero",

]
version "0.1"
matches [
{:mmh3=>'970132176'},
]
end