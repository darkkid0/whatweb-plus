Plugin.define do
name "atlassian-confluence-001"
authors [
"winezero",

]
version "0.1"
matches [

]
end