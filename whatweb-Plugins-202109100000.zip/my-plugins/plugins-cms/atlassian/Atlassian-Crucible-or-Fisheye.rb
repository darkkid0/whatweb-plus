Plugin.define do
name "Atlassian-Crucible-or-Fisheye" 
authors [
    "winezero",
]
version "0.1"
matches [
{:url=>"/favicon.ico",:allhash=>"01febf7c2bd75cd15dae3aa093d80552"},
]
end