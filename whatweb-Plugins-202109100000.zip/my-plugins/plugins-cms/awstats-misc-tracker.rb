Plugin.define do
name "awstats-misc-tracker"
authors [
"winezero",

]
version "0.1"
matches [
{:text=>'/js/awstats_misc_tracker.js'},
]
end