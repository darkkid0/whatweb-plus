Plugin.define do
name "123phpshop电商系统" 
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'123phpshop电商系统'},
]
end