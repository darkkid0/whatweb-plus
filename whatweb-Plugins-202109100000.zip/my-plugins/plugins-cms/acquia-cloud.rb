Plugin.define do
name "acquia-cloud"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"all", :text=>'Acquia Cloud'},
]
end