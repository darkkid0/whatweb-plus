Plugin.define do
name "jsp-2.x"
authors [
"winezero",

]
version "0.1"
matches [
{:search=>"headers", :text=>'JSP/2.2'},
]
end