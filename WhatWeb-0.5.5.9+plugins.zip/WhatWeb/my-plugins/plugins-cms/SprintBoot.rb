Plugin.define do
    name "SprintBoot" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :md5 => '0488faca4c19046b94d07c3ee83cf9d6'   }
]
end