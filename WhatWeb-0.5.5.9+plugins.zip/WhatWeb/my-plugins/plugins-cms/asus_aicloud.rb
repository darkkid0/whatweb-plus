Plugin.define do
    name "asus_aicloud" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '552592949'   }
]
end