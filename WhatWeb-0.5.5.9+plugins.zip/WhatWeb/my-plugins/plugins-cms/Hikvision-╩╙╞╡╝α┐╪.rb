Plugin.define do
    name "Hikvision-视频监控" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :md5 => '89b932fcc47cf4ca3faadb0cfdef89cf'   }
]
end