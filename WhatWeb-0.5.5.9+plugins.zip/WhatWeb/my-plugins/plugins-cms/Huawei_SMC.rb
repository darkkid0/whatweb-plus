Plugin.define do
    name "Huawei_SMC" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'Script/SmcScript.js?version='   }
]
end