Plugin.define do
    name "atlassian_–_confluence" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1642532491'   },
    { :mmh3 => '-305179312'   }
]
end