Plugin.define do
    name "alibaba_cloud_(block_page)" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '1227052603'   }
]
end