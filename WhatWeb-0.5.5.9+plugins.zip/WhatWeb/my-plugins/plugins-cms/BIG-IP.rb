Plugin.define do
    name "BIG-IP" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :md5 => '04d9541338e525258daf47cc844d59f3'   },
    { :mmh3 => '878647854'   }
]
end