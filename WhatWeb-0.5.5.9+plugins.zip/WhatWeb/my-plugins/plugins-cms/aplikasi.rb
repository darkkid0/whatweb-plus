Plugin.define do
    name "aplikasi" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '494866796'   }
]
end