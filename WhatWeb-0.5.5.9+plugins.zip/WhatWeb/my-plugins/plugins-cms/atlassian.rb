Plugin.define do
    name "atlassian" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '628535358'   },
    { :mmh3 => '705143395'   },
    { :mmh3 => '743365239'   }
]
end