Plugin.define do
    name "allegro-software-rompager" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'Allegro-Software-RomPager'   }
]
end