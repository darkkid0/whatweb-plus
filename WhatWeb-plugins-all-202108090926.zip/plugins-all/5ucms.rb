Plugin.define do
    name "5ucms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/admin/images/style.css', :md5 => '1f77c198658bcaf9f0df8279b3bc5418'   }
]
end