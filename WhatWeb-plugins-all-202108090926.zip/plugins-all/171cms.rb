Plugin.define do
    name "171cms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '171cms'   },
    { :text => 'content="171cms'   }
]
end