Plugin.define do
    name "Pulse_Connect_Secure" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '/dana-na/imgs/space.gif'   }
]
end