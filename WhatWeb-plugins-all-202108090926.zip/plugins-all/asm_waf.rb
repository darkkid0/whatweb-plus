Plugin.define do
    name "asm_waf" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'the requested url was rejected please consult with your administrator'  }
]
end