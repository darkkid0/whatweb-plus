Plugin.define do
    name "ayacms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/favicon.ico', :md5 => 'bbfd06120bf4169070a5e7c2c255ea03'   },
    { :url => '/static/ayacms.gif', :md5 => 'a8dcc596e48119b4ebca732f5ff4a561'   },
    { :url => '/static/sex0.jpg', :md5 => 'af7dce4fabc43e6059862362e0dd8a80'   }
]
end