Plugin.define do
    name "all_in_one_seo_pack" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :offset => 1, :regexp => /<!-- All in One SEO Pack ([\d.]+)/  }
]
end