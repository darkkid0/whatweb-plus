Plugin.define do
    name "Alibaba_Nacos" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '<title>Nacos</title>'   }
]
end