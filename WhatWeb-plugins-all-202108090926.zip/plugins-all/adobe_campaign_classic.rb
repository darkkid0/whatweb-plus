Plugin.define do
    name "adobe_campaign_classic" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-333791179'   }
]
end