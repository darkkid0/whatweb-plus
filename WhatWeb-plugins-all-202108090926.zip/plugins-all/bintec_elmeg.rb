Plugin.define do
    name "bintec_elmeg" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-375623619'   },
    { :mmh3 => '1770799630'   }
]
end