Plugin.define do
    name "bit-service" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'bit-xxzs'   },
    { :text => 'xmlpzs/webissue.asp'   }
]
end