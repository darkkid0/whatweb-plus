Plugin.define do
    name "arrisi_touchstone" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'Touchstone Status'   },
    { :text => 'passWithWarnings'   }
]
end