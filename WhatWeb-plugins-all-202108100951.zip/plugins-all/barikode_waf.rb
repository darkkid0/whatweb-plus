Plugin.define do
    name "barikode_waf" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '>barikode<'  }
]
end