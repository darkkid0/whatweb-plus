Plugin.define do
    name "51fax传真系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/images/password.gif', :md5 => 'ecc6bb79200836fd9c08cb604bbdf28c'   },
    { :url => '/images/user.gif', :md5 => '868773eab4863759e70b838180aa399f'   }
]
end