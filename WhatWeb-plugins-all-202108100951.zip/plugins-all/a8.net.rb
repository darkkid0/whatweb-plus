Plugin.define do
    name "a8.net" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => 'body', :regexp => /statics\.a8\.net/  }
]
end