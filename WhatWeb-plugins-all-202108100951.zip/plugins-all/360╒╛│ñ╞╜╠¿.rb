Plugin.define do
    name "360站长平台" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '360-site-verification'     },
    { :text => '360-site-verification'    }
]
end