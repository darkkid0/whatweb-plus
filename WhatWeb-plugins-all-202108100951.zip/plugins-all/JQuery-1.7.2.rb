Plugin.define do
    name "JQuery-1.7.2" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'webui/js/jquerylib/jquery-1.7.2.min.js'   }
]
end