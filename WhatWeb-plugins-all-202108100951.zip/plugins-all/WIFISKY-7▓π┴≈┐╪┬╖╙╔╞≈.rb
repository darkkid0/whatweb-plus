Plugin.define do
    name "WIFISKY-7层流控路由器" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :regexp => /深圳市领空技术有限公司|WIFISKY 7层流控路由器/  }
]
end