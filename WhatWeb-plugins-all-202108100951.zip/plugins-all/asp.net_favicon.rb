Plugin.define do
    name "asp.net_favicon" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '1772087922'   }
]
end