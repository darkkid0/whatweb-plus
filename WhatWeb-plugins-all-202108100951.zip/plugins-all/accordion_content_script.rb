Plugin.define do
    name "accordion_content_script" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'ddaccordion.js'   }
]
end