Plugin.define do
    name "advancedwebstats" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'caphyon-analytics.com/aws.js'   }
]
end