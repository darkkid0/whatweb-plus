Plugin.define do
    name "binatone_wr1500n" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'WR1500N'   }
]
end