Plugin.define do
    name "atlassian_–_jira" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1581907337'   },
    { :mmh3 => '552727997'   },
    { :mmh3 => '981867722'   }
]
end