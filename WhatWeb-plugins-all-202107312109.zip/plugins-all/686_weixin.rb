Plugin.define do
    name "686_weixin" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/tp/3/images/wdxx_ico3.jpg', :md5 => '92ae1e5dade901786fd83a316d94cfa0'   }
]
end