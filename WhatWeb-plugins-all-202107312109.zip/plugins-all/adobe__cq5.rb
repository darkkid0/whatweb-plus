Plugin.define do
    name "adobe__cq5" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => '_jcr_content'   }
]
end