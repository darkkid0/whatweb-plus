Plugin.define do
    name "25yi" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'Powered by 25yi'   },
    { :text => 'css/25yi.css'   }
]
end