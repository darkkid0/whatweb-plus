Plugin.define do
    name "apache_tomcat" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-297069493'    },
    { :offset => 1, :search => 'headers[x-powered-by]', :regexp => /\bTomcat\b(?:-([\d.]+))?/   },
    { :search => 'headers[server]', :regexp => /^Apache-Coyote/   }
]
end