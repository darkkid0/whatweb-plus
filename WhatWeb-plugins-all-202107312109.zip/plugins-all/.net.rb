Plugin.define do
    name ".net" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'content="Visual Basic .NET 7.1'   }
]
end