Plugin.define do
    name "3gmeeting视讯系统" 
    authors [
        "winezero",

    ]
    version "0.1"
matches [
    {:url=>'/images/an_on.jpg', :md5=>'f0c48c3ab92948f55bf328a2470653a6'},
    {:url=>'/images/download.jpg', :md5=>'816b4187721f32088960efaed2884b5a'},
    {:url=>'/images/download.jsp', :md5=>'6ac63e4862841ebb76a1954deca7f4c9'}
]
end