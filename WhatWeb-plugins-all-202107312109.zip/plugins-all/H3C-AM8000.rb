Plugin.define do
    name "H3C-AM8000" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'AM8000'   }
]
end