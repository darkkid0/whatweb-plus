Plugin.define do
    name "asus_rtac66u" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'RT-AC66U'   },
    { :text => 'RT-AC66U'   }
]
end