Plugin.define do
    name "aethra_telecommunications_operating_system" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'atos'   }
]
end