Plugin.define do
    name "alibi_nvr" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '1876585825'   }
]
end