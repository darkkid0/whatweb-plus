Plugin.define do
    name "Shiro" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => '=deleteMe'   },
    { :search => "headers", :text => 'rememberMe='   },
    { :serach => 'headers', :text => '=deleteMe|rememberMe='   }
]
end