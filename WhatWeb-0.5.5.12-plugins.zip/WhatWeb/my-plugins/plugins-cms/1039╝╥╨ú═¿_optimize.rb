Plugin.define do
    name "1039家校通" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ 
    { :url => '/images/jxt_login_bg.gif', :md5 => '21224af1da24ba961ed4c55b4d6f78cb'   },
    { :url => '/images/jxt_logo.gif', :md5 => '8adfb204fc17450fa124ccfdab09b412'   },
    { :url => '/images/jxt_logo.gif', :md5 => 'd9a4ebcfc4eec9120f881224b9768e2c'   },
    { :url => '/css/stuselect/index.css', :text => 'height: 35px; position: relative'   },
]
end