Plugin.define do
    name "avigilon" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '1318124267'   }
]
end