Plugin.define do
    name "VMware_vCenter" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'VMware vCenter'   }
]
end