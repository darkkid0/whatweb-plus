Plugin.define do
    name "beidou" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/Admin/db/s.css', :md5 => '2e62e2d28ae4fcc2a9038e0f15c2c6bd'   }
]
end