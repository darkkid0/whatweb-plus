Plugin.define do
    name "APACHE-kylin" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'url=kylin'   }
]
end