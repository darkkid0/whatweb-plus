Plugin.define do
    name "appcms" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'Powerd by AppCMS'   },
    { :url => '/templates/default/css/img/index/bg-skirt.gif', :md5 => '62029ccf4af64fda36a380c334ee2a3c'   },
    { :url => '/templates/default/css/img/index/bg-topic-special.png', :md5 => 'a5b8c5f135daba35c26ef18b8920993f'   },
    { :url => '/templates/default/css/img/stars.gif', :md5 => '1d0c675c0c08249f75a6ce7984f96470'   }
]
end