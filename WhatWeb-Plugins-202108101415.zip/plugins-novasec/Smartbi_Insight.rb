Plugin.define do
    name "Smartbi_Insight" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'smartbi.gcf.gcfutil'   }
]
end