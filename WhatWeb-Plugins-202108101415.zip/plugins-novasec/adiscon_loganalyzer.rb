Plugin.define do
    name "adiscon_loganalyzer" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'Adiscon GmbH")'   },
    { :text => 'Adiscon LogAnalyzer'   }
]
end