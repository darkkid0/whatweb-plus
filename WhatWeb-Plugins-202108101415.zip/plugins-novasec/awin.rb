Plugin.define do
    name "awin" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => 'body', :regexp => /dwin1\.com/  }
]
end