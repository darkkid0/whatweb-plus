Plugin.define do
    name "anmai安脉教务管理系统" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :url => '/anmai/Edis/css/sudjectdiscusscss.css', :md5 => '00c1372beab553740afd73f4361a4ff3'   },
    { :url => '/anmai/images/logobot.gif', :md5 => '001c0f78b68aa2f54eed8a91839e91a8'   },
    { :url => '/images/logobot.gif', :md5 => 'e533cdba3c0cf1b165c24522389b5f58'   }
]
end