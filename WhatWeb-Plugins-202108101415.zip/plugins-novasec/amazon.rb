Plugin.define do
    name "amazon" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :mmh3 => '-1544605732'   },
    { :mmh3 => '716989053'   }
]
end