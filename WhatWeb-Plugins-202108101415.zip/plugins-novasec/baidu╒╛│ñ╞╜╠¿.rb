Plugin.define do
    name "baidu站长平台" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :text => 'baidu-site-verification'   }
]
end