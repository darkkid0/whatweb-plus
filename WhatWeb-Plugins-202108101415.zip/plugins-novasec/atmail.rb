Plugin.define do
    name "atmail" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => 'atmail6'   },
    { :text => 'FixShowMail'   },
    { :text => 'Powered by Atmail'   }
]
end