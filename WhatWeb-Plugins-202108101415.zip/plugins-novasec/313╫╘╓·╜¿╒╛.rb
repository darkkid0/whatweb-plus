Plugin.define do
    name "313自助建站" 
    authors [
        "winezero",

    ]
    version "0.1"
    matches [ { :search => "headers", :text => '313CMS'   }
]
end